public class Variables {

    public static void main(String[] args) {
        int number = 10;
        char letter = 'a';
        boolean result = true;
        String str =  "hello";

        System.out.println("Number = " + number);
        System.out.println("letter = " + letter);
        System.out.println("result = " + result);
        System.out.println("str = " + str);
    }    
}